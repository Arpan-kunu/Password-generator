import React, { useState, useEffect } from "react";
import "./App.css";

function App() {
  const [password, setPassword] = useState("");
  const [passwordHistory, setPasswordHistory] = useState([]);

  const generatePassword = () => {
    const length = 12; 
    const charset =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-+=<>?"; 
    let newPassword = "";

    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      newPassword += charset[randomIndex];
    }

    setPassword(newPassword);

    
    const updatedHistory = [newPassword, ...passwordHistory];
    setPasswordHistory(updatedHistory);

    
    localStorage.setItem("passwordHistory", JSON.stringify(updatedHistory));
  };

  const copyToClipboard = () => {
    navigator.clipboard
      .writeText(password)
      .then(() => {
        alert("Password copied to clipboard!");
      })
      .catch((error) => {
        console.error("Error copying password:", error);
      });
  };

  useEffect(() => {
    
    const storedHistory = localStorage.getItem("passwordHistory");
    if (storedHistory) {
      setPasswordHistory(JSON.parse(storedHistory));
    }
  }, []);

  return (
    <div className="App">
      <div className="password-generator">
        <h1>Password Generator</h1>
        <button onClick={generatePassword}>Generate Password</button>
        <div className="generated-password">
          <h2>Generated Password</h2>
          <p>{password}</p>
          <button onClick={copyToClipboard}>Copy to Clipboard</button>
        </div>
      </div>

      <div className="password-history">
        <h2>Password History</h2>
        <ul>
          {passwordHistory.slice(0, 5).map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
